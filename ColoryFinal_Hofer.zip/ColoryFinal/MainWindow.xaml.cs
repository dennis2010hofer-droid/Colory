﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace Colory
{
    public partial class MainWindow : Window
    {
        private List<FarbEintrag> _palette = new List<FarbEintrag>();

        private double _basisH, _basisS, _basisV;
        private int _paletteGroesse = 3;

        private Random _zufall = new Random();
        private ToggleButton[] _anzahlButtons;

        public MainWindow()
        {
            InitializeComponent();
            _anzahlButtons = new ToggleButton[] { Btn2, Btn3, Btn4, Btn5, Btn6 };
            AktualisiereVorschau();
        }

        private void HexInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            AktualisiereVorschau();
        }

        private void AktualisiereVorschau()
        {
            try
            {
                var farbe = (Color)ColorConverter.ConvertFromString(HexInput.Text.Trim());
                FarbvorschauBox.Background = new SolidColorBrush(farbe);
            }
            catch { }
        }

        private void AnzahlBtn_Checked(object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn == null || _anzahlButtons == null) return;

            foreach (var b in _anzahlButtons)
                if (b != btn) b.IsChecked = false;

            _paletteGroesse = int.Parse(btn.Tag.ToString());
            AktualisiereTypZeilen();
        }

        private void AnzahlBtn_Unchecked(object sender, RoutedEventArgs e)
        {
            if (_anzahlButtons == null) return;
            ToggleButton btn = sender as ToggleButton;
            if (btn != null && !IstEinerChecked())
                btn.IsChecked = true;
        }

        private bool IstEinerChecked()
        {
            foreach (var b in _anzahlButtons)
                if (b.IsChecked == true) return true;
            return false;
        }

        private void AktualisiereTypZeilen()
        {
            if (TypZeile3 == null) return;
            TypZeile3.Visibility = _paletteGroesse >= 3 ? Visibility.Visible : Visibility.Collapsed;
            TypZeile4.Visibility = _paletteGroesse >= 4 ? Visibility.Visible : Visibility.Collapsed;
            TypZeile5.Visibility = _paletteGroesse >= 5 ? Visibility.Visible : Visibility.Collapsed;
            TypZeile6.Visibility = _paletteGroesse >= 6 ? Visibility.Visible : Visibility.Collapsed;
        }

        private string LeseTyp(ComboBox box)
        {
            ComboBoxItem item = box.SelectedItem as ComboBoxItem;
            if (item == null) return "Harmonisch";
            return item.Content.ToString();
        }

        private void PaletteGenerieren_Click(object sender, RoutedEventArgs e)
        {
            Color basisfarbe;
            try
            {
                basisfarbe = (Color)ColorConverter.ConvertFromString(HexInput.Text.Trim());
            }
            catch
            {
                MessageBox.Show("Bitte einen gültigen HEX-Code eingeben.  Beispiel: #6366F1");
                return;
            }

            RgbZuHsv(basisfarbe, out _basisH, out _basisS, out _basisV);

            ComboBox[] dropdowns = new ComboBox[] { Typ1, Typ2, Typ3, Typ4, Typ5, Typ6 };

            _palette.Clear();
            for (int i = 0; i < _paletteGroesse; i++)
            {
                string typ = LeseTyp(dropdowns[i]);
                Color farbe = BerechneEinzelfarbe(_basisH, _basisS, _basisV, i, _paletteGroesse, typ);
                _palette.Add(EintragErstellen(farbe, typ, i));
            }

            AktualisiereBalken();
            FarbkachelListe.ItemsSource = null;
            FarbkachelListe.ItemsSource = _palette;
            PlatzhalterPanel.Visibility = Visibility.Collapsed;
            ErgebnisPanel.Visibility = Visibility.Visible;
        }

        private Color BerechneEinzelfarbe(double h, double s, double v, int index, int gesamt, string typ, double offset = 0)
        {
            switch (typ)
            {
                case "Spot":
                    return HsvZuColor((h + 180 + index * 30 + offset) % 360, Math.Min(s + 0.35, 1.0), Math.Max(v, 0.85));

                case "Harmonisch":
                    return HsvZuColor((h + index * (360.0 / gesamt) + offset) % 360, s, v);

                default: // Gleichton
                    double neuesV = v - 0.2 + index * (0.4 / Math.Max(gesamt - 1, 1)) + offset * 0.005;
                    if (neuesV < 0.15) neuesV = 0.15;
                    if (neuesV > 1.0) neuesV = 1.0;
                    return HsvZuColor(h, s, neuesV);
            }
        }

        private FarbEintrag EintragErstellen(Color farbe, string typ, int index)
        {
            bool istHell = farbe.R * 0.299 + farbe.G * 0.587 + farbe.B * 0.114 > 140;
            Color textfarbe = istHell ? Color.FromArgb(220, 20, 20, 20) : Color.FromArgb(220, 255, 255, 255);
            SolidColorBrush badgeHintergrund;
            SolidColorBrush badgeTextfarbe;
            string typLabel;

            if (typ == "Spot")
            {
                badgeHintergrund = new SolidColorBrush(Color.FromRgb(249, 115, 22));
                badgeTextfarbe = new SolidColorBrush(Colors.White);
                typLabel = "Spot";
            }
            else
            {
                Color badgeFarbe = istHell ? Color.FromArgb(35, 0, 0, 0) : Color.FromArgb(35, 255, 255, 255);
                badgeHintergrund = new SolidColorBrush(badgeFarbe);
                badgeTextfarbe = new SolidColorBrush(textfarbe);
                typLabel = typ;
            }

            return new FarbEintrag
            {
                HexCode = string.Format("#{0:X2}{1:X2}{2:X2}", farbe.R, farbe.G, farbe.B),
                Typ = typ,
                TypLabel = typLabel,
                Index = index,
                Hintergrund = new SolidColorBrush(farbe),
                Textfarbe = new SolidColorBrush(textfarbe),
                BadgeHintergrund = badgeHintergrund,
                BadgeTextfarbe = badgeTextfarbe
            };
        }

        private void Aendern_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;
            FarbEintrag eintrag = btn.DataContext as FarbEintrag;
            if (eintrag == null) return;

            double offset = _zufall.NextDouble() * 50 - 25;
            Color neueFarbe = BerechneEinzelfarbe(_basisH, _basisS, _basisV, eintrag.Index, _paletteGroesse, eintrag.Typ, offset);
            _palette[eintrag.Index] = EintragErstellen(neueFarbe, eintrag.Typ, eintrag.Index);

            FarbkachelListe.ItemsSource = null;
            FarbkachelListe.ItemsSource = _palette;
            AktualisiereBalken();
        }

        private void AktualisiereBalken()
        {
            FarbbalkenGrid.ColumnDefinitions.Clear();
            FarbbalkenGrid.Children.Clear();

            for (int i = 0; i < _palette.Count; i++)
            {
                FarbbalkenGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                var segment = new System.Windows.Shapes.Rectangle { Fill = _palette[i].Hintergrund };
                Grid.SetColumn(segment, i);
                FarbbalkenGrid.Children.Add(segment);
            }
        }

        private void Kachel_Klick(object sender, MouseButtonEventArgs e)
        {
            Border border = sender as Border;
            if (border == null) return;
            FarbEintrag eintrag = border.DataContext as FarbEintrag;
            if (eintrag != null && eintrag.HexCode != null)
                Clipboard.SetText(eintrag.HexCode);
        }

        private void Kopieren_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                FarbEintrag eintrag = btn.DataContext as FarbEintrag;
                if (eintrag != null && eintrag.HexCode != null)
                {
                    Clipboard.SetText(eintrag.HexCode);
                    return;
                }
            }
            Clipboard.SetText(HexInput.Text.Trim());
        }

        private void RgbZuHsv(Color c, out double h, out double s, out double v)
        {
            double r = c.R / 255.0, g = c.G / 255.0, b = c.B / 255.0;
            double max = Math.Max(r, Math.Max(g, b));
            double min = Math.Min(r, Math.Min(g, b));
            double delta = max - min;

            v = max;
            s = max == 0 ? 0 : delta / max;

            if (delta == 0) { h = 0; return; }

            if (max == r) h = 60 * (((g - b) / delta) % 6);
            else if (max == g) h = 60 * ((b - r) / delta + 2);
            else h = 60 * ((r - g) / delta + 4);

            if (h < 0) h += 360;
        }

        private Color HsvZuColor(double h, double s, double v)
        {
            if (s == 0) { byte grau = (byte)(v * 255); return Color.FromRgb(grau, grau, grau); }

            h /= 60;
            int i = (int)Math.Floor(h) % 6;
            double f = h - Math.Floor(h);
            double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);

            double r, g, b;
            switch (i)
            {
                case 0: r = v; g = t; b = p; break;
                case 1: r = q; g = v; b = p; break;
                case 2: r = p; g = v; b = t; break;
                case 3: r = p; g = q; b = v; break;
                case 4: r = t; g = p; b = v; break;
                default: r = v; g = p; b = q; break;
            }

            return Color.FromRgb((byte)(r * 255), (byte)(g * 255), (byte)(b * 255));
        }
    }

    public class FarbEintrag
    {
        public string HexCode { get; set; }
        public string Typ { get; set; }
        public string TypLabel { get; set; }
        public int Index { get; set; }
        public SolidColorBrush Hintergrund { get; set; }
        public SolidColorBrush Textfarbe { get; set; }
        public SolidColorBrush BadgeHintergrund { get; set; }
        public SolidColorBrush BadgeTextfarbe { get; set; }
    }
}